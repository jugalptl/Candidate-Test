/**
 * Created by iGroup on 4/24/2016.
 */

function AppCtrl(){

    console.log("hello form controller");
}


/*Code to solve problem in actual database */


function AppControl($scope,$http) {
console.log("Hello world from controller");


var refresh = function()
{

$http.get('/candidate-test').success(function(response){

console.log(" I got the data i requested");
$scope.Ruglist = response;
$scope.Ruglist = ""; // Clears the field as soon as the data is updated in to listview
});

}
refresh();

/* Below function alloews you to add rug information into database. This function is called on Add Rug button click*/

$scope.addRug = function()
{
 console.log($scope.Rug);
 $http.post('/Ruglist',$scope.Rug).sucess(function(response){
    console.log('response');
    refresh();
 });
};


/* Below function alloews you to remove rug information from database. This function is called on Remove button click*/

$scope.remove = function(id)
{
    console.log(id);
    $http.delete('/Ruglist/'+ id).success(function(response){
        refresh();
    }); 
}


/* Below function alloews you to edit rug information from database. This function is called on Edit button click*/
    
$scope.edit = function(id)
{
    console.log(id);
    $http.delete('/Ruglist/'+ id).success(function(response){
        $scope.rug = response;
    }); 
}


/* Below function alloews you to Update rug information from database. This function is called on Update button click*/
    
$scope.Update = function(id)
{
    console.log($scope.Rug.id);
    $http.put('/Ruglist/'+ $scope.Rug.id).success(function(response){
        refresh();
    }); 
}




}



/* Code using dummy data*/
var app = angular.module('RugInfoApp',[]);
app.controller("AppCtrl", function ($scope) {

    $scope.info="Hello from controller"

    RugType1= {
        name: 'Traditional',
        shape: 'square',
        size: '5 x 7',
        color: 'Blue'
    };
    RugType2= {
        name: 'Contemporary',
        shape: 'square',
        size: '25 X 20',
        color: 'Black'
    };
    var Ruglist = [RugType1,RugType2];
    //res.json(contactlist);
    $scope.Ruglist = Ruglist;
});


