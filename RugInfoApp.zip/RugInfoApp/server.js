var express = require('express');
var app = express();

//var app = angular.module("RugInfoApp",[]);

var mongojs =require{'mongojs'};
var db = mongojs('candidate-test',['candidate-test']);
var bodyParser = require('bodyparser');

app.use(express.static(__dirname+"/public"));
app.use(bodyParser.json); // server can Parse the body input data receive

/* Get Request to database in MongoDB to get respose back in JSON Format*/
app.get('candidate-test',function(req,res){

console.log('I receive a get request');
db.candidate-test.find(function(err,docs)
{
console.log(docs);
res.json(docs);
});
});

app.post('/candidate-test',function(req,res)
{
	console.log(req.body);
	db.candidate-test.insert(req.body,function(err,docs){
		res.docs(json);
	});
});


app.delete('/candidate-test:id',function(req,res)
{
	var id = req.params.id;
	console.log(id);
	db.candidate-test.remove({_id: mongojs.objectId(id)},function(err,doc){
		res.json(doc);
	});

});



app.get('/candidate-test:id',function(req,res)
{
	var id = req.params.id;
	console.log(id);
	db.candidate-test.findOne({_id: mongojs.objectId(id)},function(err,doc){
		res.json(doc);
	});

});


app.put('/candidate-test:id',function(req,res)
{
	var id = req.params.id;
	console.log(req.body.name);	
	db.candidate-test.findAndModify({query:{_id:mongojs.objectId(id)} ,
		update:{ $set:{name:req.body.name, shape:req.body.shape, size:req.body.size,color:req.body.color}},new :true}, function(err,doc){
		res.json(doc);
	});	

});

app.listen(3000);
console.log("server running on port 3000");
